// read this file, and turn it into dynamodb tables.
// when creating vtl, map userId and orgId, to PK and GSI1

module.exports = {
    notes: {
        type: 'relational',
        id: 'id',
        userId: 'relationship',
        orgId: 'relationship'
    },

    users: {
        type: 'simple',
        id: 'id'
    }
}